from .Base import Base

class 学生(Base):
    学号: str
    姓名: str
    性别: str
    年龄: int
    班级: str
