from .Base import Base

class 课程(Base):
    课程编号: str
    名称: str
    学分: int