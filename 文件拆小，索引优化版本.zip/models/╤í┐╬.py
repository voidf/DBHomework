from .Base import Base

class 选课(Base):
    学号: str
    课程编号: str
    成绩: int