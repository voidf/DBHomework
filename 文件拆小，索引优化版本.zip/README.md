# 开发环境


- python 3.8+
- pip    20.1+
- Windows Server 2019 Datacenter

> 但大概py3.7+都能跑

# 安装依赖

`pip install -r requirements.txt`

# 运行

`python main.py`

# 使用

浏览器访问[http://localhost:5000/docs](http://localhost:5000/docs)